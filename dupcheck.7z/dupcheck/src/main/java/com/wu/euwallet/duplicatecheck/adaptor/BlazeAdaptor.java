package com.wu.euwallet.duplicatecheck.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.euwallet.duplicatecheck.config.BlazeConfig;
import com.wu.euwallet.duplicatecheck.exception.exceptiontype.WUExceptionType;
import com.wu.euwallet.duplicatecheck.exception.utils.WUServiceExceptionUtils;
import com.wu.euwallet.duplicatecheck.model.request.blaze.BlazeRiskRequest;
import com.wu.era.library.exception.exceptiontype.WUExceptionType;
import com.wu.era.library.exception.exceptiontype.WUServiceException;
import com.wu.era.library.exception.utils.WUServiceExceptionUtils;
import com.wu.euwallet.duplicatecheck.model.request.blaze.RiskCheckRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
@RequiredArgsConstructor
public class BlazeAdaptor {

    private final BlazeConfig blazeConfig;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Retryable(maxAttempts = 3)
    public String performRiskCheck(RiskCheckRequest request) {
        String url = blazeConfig.getBaseUrl() + blazeConfig.getEndpoint();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("x-api-key", blazeConfig.getApiKey());

        BlazeRiskRequest requestPayload = new BlazeRiskRequest(request.getCustomerNumber());
        try {
            String jsonPayload = objectMapper.writeValueAsString(requestPayload);
            HttpEntity<String> requestEntity = new HttpEntity<>(jsonPayload, headers);

            ResponseEntity<String> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    requestEntity,
                    String.class
            );

            return response.getBody();

        } catch (Exception ex) {
            log.error("Error during Blaze risk check: {}", ex.getMessage(), ex);
            throw new WUServiceExceptionUtils().buildWUServiceException(
                    WUExceptionType.BLAZE_ERROR,
                    "Blaze risk check failed",
                    ex
            );
        }
    }
}