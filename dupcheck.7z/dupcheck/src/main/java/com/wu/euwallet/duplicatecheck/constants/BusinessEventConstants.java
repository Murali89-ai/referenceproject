package com.wu.euwallet.duplicatecheck.constants;

public class BusinessEventConstants {
    public static final String PROFILE_UPDATE_EVENT_NAME = "PROFILE_UPDATE";
    public static final String EVENT_TYPE = "CUSTOMER_PROFILE";
    public static final String EVENT_VERSION = "v1";
}