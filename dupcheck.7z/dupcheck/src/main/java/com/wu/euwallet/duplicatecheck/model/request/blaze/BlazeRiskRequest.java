package com.wu.euwallet.duplicatecheck.model.request.blaze;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlazeRiskRequest {
    private String customerId;
}