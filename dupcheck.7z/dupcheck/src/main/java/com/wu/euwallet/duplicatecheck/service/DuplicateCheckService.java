package com.wu.euwallet.duplicatecheck.service;

import com.wu.euwallet.duplicatecheck.dto.ProfileUpdateRequest;
import com.wu.euwallet.duplicatecheck.dto.DuplicateCheckResponse;

public interface DuplicateCheckService {
    DuplicateCheckResponse processProfileUpdate(ProfileUpdateRequest request);
}
