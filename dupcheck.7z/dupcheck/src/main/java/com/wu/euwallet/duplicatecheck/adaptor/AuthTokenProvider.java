package com.wu.euwallet.duplicatecheck.adaptor;

import com.wu.euwallet.duplicatecheck.config.AuthTokenConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Component
@RequiredArgsConstructor
public class AuthTokenProvider {

    private final RestTemplate restTemplate;
    private final AuthTokenConfig authTokenConfig;

    @Retryable(maxAttempts = 2)
    public String getBearerToken() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(authTokenConfig.getClientId(), authTokenConfig.getClientSecret());
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<String> req = new HttpEntity<>("grant_type=client_credentials", headers);
        ResponseEntity<AuthTokenResponse> res = restTemplate.exchange(
                authTokenConfig.getTokenUrl(), HttpMethod.POST, req, AuthTokenResponse.class);

        return "Bearer " + res.getBody().getAccessToken();
    }
}