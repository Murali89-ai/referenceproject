package com.wu.euwallet.duplicatecheck.service.impl;

import com.wu.euwallet.duplicatecheck.adaptor.BlazeAdaptor;
import com.wu.euwallet.duplicatecheck.config.KafkaTopicsConfig;
import com.wu.euwallet.duplicatecheck.dto.ProfileUpdateRequest;
import com.wu.euwallet.duplicatecheck.dto.DuplicateCheckResponse;
import com.wu.euwallet.duplicatecheck.exception.exceptiontype.WUExceptionType;
import com.wu.euwallet.duplicatecheck.exception.utils.WUServiceExceptionUtils;
import com.wu.euwallet.duplicatecheck.kafka.KafkaHeadersUtil;
import com.wu.euwallet.duplicatecheck.kafka.producer.KafkaProducerService;
import com.wu.euwallet.duplicatecheck.model.request.blaze.RiskCheckRequest;
import com.wu.euwallet.duplicatecheck.model.response.blaze.RiskCheckResponse;
import com.wu.euwallet.duplicatecheck.service.DuplicateCheckService;
import com.wu.euwallet.duplicatecheck.service.HttpService;
import com.wu.euwallet.duplicatecheck.validation.RequestValidator;
import com.wu.euwallet.duplicatecheck.transform.UcdUpdateRequestBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.header.Headers;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

/**
 * Concrete implementation that:
 * <ol>
 *   <li>Validates the inbound {@link ProfileUpdateRequest}</li>
 *   <li>Transforms it to the request format expected by the UCD profile-update API</li>
 *   <li>Sends the transformed payload to the UCD service (synchronous REST)</li>
 *   <li>Publishes a “business-event” message to Kafka for downstream async processing</li>
 * </ol>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DuplicateCheckServiceImpl implements DuplicateCheckService {

    private final RequestValidator validator;
    private final UcdUpdateRequestBuilder ucdRequestBuilder;
    private final HttpService httpService;
    private final KafkaProducerService kafkaProducer;
    private final KafkaTopicsConfig kafkaTopics;
    private final BlazeAdaptor blazeAdaptor;

    @Override
    public DuplicateCheckResponse processProfileUpdate(ProfileUpdateRequest request) {

        /* ---------- 1. Validate incoming request ---------- */
        validator.validate(request);
        log.debug("Request validation SUCCESS for customerUmn={}", request.getCustomerUmn());

        /* ---------- 2. Build UCD-specific request ---------- */
        Map<String, Object> ucdPayload = ucdRequestBuilder.buildRequest(request);
        log.debug("UCD request built -> {}", ucdPayload);

        /* ---------- 3. Invoke UCD profile-update service ---------- */
        Map<String, Object> ucdResponse = httpService.postForObject(
                "/ucd/customer/profile/addorupdate",   // path is externalised in `application.yaml`
                ucdPayload, Map.class);
        log.info("UCD profile-update API responded with {}", ucdResponse);

        /* ---------- 4. Produce Kafka business-event ---------- */
        String correlationId = UUID.randomUUID().toString();
        String externalReferenceId = request.getCustomerUmn();
        String upstreamServiceName = "duplicate-check-svc";

        Headers headers = KafkaHeadersUtil.buildStandardHeaders(
                correlationId,
                externalReferenceId,
                upstreamServiceName);

        // Serialise as JSON via KafkaProducerService – it hides ObjectMapper details
        kafkaProducer.send(
                kafkaTopics.getBusinessTopic(),
                ucdResponse,
                headers);

        /* ---------- 5. Prepare & return API response ---------- */
        return DuplicateCheckResponse.builder()
                .customerUmn(request.getCustomerUmn())
                .transactionId(correlationId)
                .status("SUCCESS")
                .description("Duplicate-check processed and UCD profile updated")
                .build();
    }


    public void validateRisk(ProfileUpdateRequest request) {
        RiskCheckRequest riskCheckRequest = RiskCheckRequest.builder()
                .customerNumber(request.getCustomerNumber())
                .channel(request.getChannel())
                .transactionId(UUID.randomUUID().toString())
                .build();

        RiskCheckResponse response = blazeAdaptor.performRiskCheck(riskCheckRequest);

        if (!"APPROVED".equalsIgnoreCase(response.getDecision())) {
            throw new WUServiceExceptionUtils().buildWUServiceException(
                    WUExceptionType.BLAZE_RISK_REJECTED,
                    "Blaze rejected the transaction: " + response.getReason()
            );
        }
    }
}
