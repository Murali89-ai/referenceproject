package com.wu.euwallet.duplicatecheck.model.common.kafka;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProfileUpdatePayload {
    private String customerNumber;
    private String mobileNumber;
    private String emailId;
    private String firstName;
    private String lastName;
    private String language;
    private String channel;
    private String transactionId;
}