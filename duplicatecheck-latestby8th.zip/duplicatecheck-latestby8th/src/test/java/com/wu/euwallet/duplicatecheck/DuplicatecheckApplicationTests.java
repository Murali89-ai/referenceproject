package com.wu.euwallet.duplicatecheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuplicatecheckApplicationTests {

	//@Test
	void contextLoads() {
	}

}
