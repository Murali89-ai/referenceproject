package com.wu.euwallet.duplicatecheck.model.response.marqeta;

import lombok.Data;

@Data
public class CardUpdateResponse {
    private String token;
    private String status;
}
