// model/response/biz/BizCardResponse.java
package com.wu.euwallet.duplicatecheck.model.response.biz;

import lombok.Data;

@Data
public class BizCardResponse {
    private String cardNumber;
    private String status;
}
