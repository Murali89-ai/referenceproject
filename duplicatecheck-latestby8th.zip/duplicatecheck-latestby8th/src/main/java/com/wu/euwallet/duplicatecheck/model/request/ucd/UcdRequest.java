package com.wu.euwallet.duplicatecheck.model.request.ucd;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UcdRequest {

    @JsonProperty("customerLookup")
    private CustomerLookup customerLookup;

    @JsonProperty("header")
    private Header header;

    @JsonProperty("keyBased")
    private boolean keyBased;

    @JsonProperty("requestInitiatedBy")
    private String requestInitiatedBy;

    @JsonProperty("channelType")
    private int channelType;

    @JsonProperty("sendPartnerDetails")
    private String sendPartnerDetails;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomerLookup {
        @JsonProperty("customerKey")
        private Map<String, String> customerKey;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Header {
        @JsonProperty("source")
        private String source;

        @JsonProperty("appName")
        private String appName;

        @JsonProperty("appVersion")
        private String appVersion;

        @JsonProperty("timeStamp")
        private String timeStamp;

        @JsonProperty("transactionId")
        private String transactionId;
    }
}