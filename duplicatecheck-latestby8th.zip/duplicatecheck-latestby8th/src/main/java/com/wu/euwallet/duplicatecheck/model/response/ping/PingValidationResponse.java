package com.wu.euwallet.duplicatecheck.model.response.ping;

import lombok.Data;

@Data
public class PingValidationResponse {
    private boolean valid;
}
