package com.wu.euwallet.duplicatecheck.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.euwallet.duplicatecheck.aop.LoggingAnnotation;
import com.wu.euwallet.duplicatecheck.config.UcdConfig;
import com.wu.euwallet.duplicatecheck.exception.exceptiontype.WUExceptionType;
import com.wu.euwallet.duplicatecheck.exception.exceptiontype.WUServiceException;
import com.wu.euwallet.duplicatecheck.exception.utils.WUServiceExceptionUtils;
import com.wu.euwallet.duplicatecheck.model.request.ucd.UcdRequest;
import com.wu.euwallet.duplicatecheck.model.response.ucd.UcdResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

@RequiredArgsConstructor
@Component
public class UcdAdaptor {

    private static final Logger log = LoggerFactory.getLogger(UcdAdaptor.class);

    private final RestTemplate restTemplate;
    private final AuthTokenProvider authTokenProvider;
    private final ObjectMapper objectMapper;
    private final UcdConfig ucdConfig;

    @LoggingAnnotation
    @Retryable(
            value = { WUServiceException.class },
            maxAttempts = 3,
            backoff = @Backoff(delay = 2000))
    public UcdResponse lookupCustomer(UcdRequest request, String correlationId) {
        String url = ucdConfig.getBaseUrl() + ucdConfig.getLookupPath();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("x-api-key", ucdConfig.getApiKey());
        headers.set("x-wu-correlationId", correlationId);
        headers.setBearerAuth(authTokenProvider.getAccessToken()); // Dynamic token injection

        HttpEntity<UcdRequest> entity = new HttpEntity<>(request, headers);

        try {
            ResponseEntity<UcdResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    UcdResponse.class
            );
            return response.getBody();
        } catch (HttpStatusCodeException ex) {
            log.error("UCD lookup failed: {}", ex.getResponseBodyAsString(), ex);
            throw WUServiceExceptionUtils.buildWUServiceException(
                    WUExceptionType.UCD_ERROR,
                    "UCD lookup failed with status: " + ex.getStatusCode(),
                    ex
            );
        }
    }
}