package com.wu.euwallet.duplicatecheck.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wu.euwallet.duplicatecheck.adaptor.MambuAdaptor;
import com.wu.euwallet.duplicatecheck.adaptor.UcdAdaptor;
import com.wu.euwallet.duplicatecheck.exception.exceptiontype.WUExceptionType;
import com.wu.euwallet.duplicatecheck.exception.utils.WUServiceExceptionUtils;
import com.wu.euwallet.duplicatecheck.kafka.producer.ProfileUpdateKafkaProducer;
import com.wu.euwallet.duplicatecheck.model.response.ProfileUpdateResponse;
import com.wu.euwallet.duplicatecheck.service.DuplicateCheckService;
import com.wu.euwallet.duplicatecheck.service.MarqetaUpdateService;
import com.wu.euwallet.duplicatecheck.transformer.UcdUpdateRequestBuilder;
import com.wu.euwallet.duplicatecheck.utils.ValidationUtils;
import com.wu.euwallet.duplicatecheck.validation.RequestValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class DuplicateCheckServiceImpl implements DuplicateCheckService {

    /* ── Dependencies ───────────────────────────────────────────────────── */
    private final RequestValidator validator;
    private final UcdAdaptor                  ucdAdaptor;
    private final MambuAdaptor                mambuAdaptor;
    private final MarqetaUpdateService        marqetaUpdateService;
    private final UcdUpdateRequestBuilder     ucdBuilder;
    private final ProfileUpdateKafkaProducer kafkaProducer;
    private final ObjectMapper                mapper;

    @Override
    public ProfileUpdateResponse updateProfile(com.wu.euwallet.duplicatecheck.model.request.ProfileUpdateRequest req) {
        // 1. Validate mandatory field
        ValidationUtils.notBlank(req.getCustomerNumber(), "customerNumber is mandatory");

        // 2. Build UCD request
        JsonNode lookupBody =  ucdBuilder.buildLookup(req);

        // 3. UCD Lookup
        JsonNode lookupResponse = ucdAdaptor.lookupCustomer(lookupBody);
        if (!lookupResponse.path(AppConstants.UCD_LOOKUP_PATH).asBoolean()) {
            throw WUServiceExceptionUtils.buildWUServiceException(
                    WUExceptionType.DUPLICATE_CUSTOMER_DETECTED_IN_UCD,
                    "Duplicate customer detected in UCD");
        }

        // 4. Mambu Update
        mambuAdaptor.updateCustomer(req);

        // 5. Marqeta Update
        marqetaUpdateService.process(mapper.writeValueAsString(req));

        // 6. Prepare and return response
        return ProfileUpdateResponse.builder()
                .message("Profile update successfully completed")
                .status("SUCCESS")
                .build();
    }
}