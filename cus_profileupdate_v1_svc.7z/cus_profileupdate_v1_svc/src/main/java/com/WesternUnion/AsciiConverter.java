package com.WesternUnion;


public class AsciiConverter{

	 
	 static String NON_ASCII = "\u2019\u00C0\u00E0\u00C8\u00E8\u00CC\u00EC\u00D2\u00F2\u00D9\u00F9\u00C1\u00E1\u00C9\u00E9\u00CD\u00ED\u00F3\u00DA\u00FA\u00DD\u00FD\u00C2\u00E2\u00CA\u00EA\u00CE\u00EE\u00D4\u00F4\u00DB\u00FB\u0176\u0177\u00C3\u00E3\u00D5\u00F5\u00D1\u00F1\u00C4\u00E4\u00CB\u00EB\u00CF\u00EF\u00D6\u00F6\u00DC\u00FC\u0178\u00FF\u00C5\u00E5\u00C7\u00E7\u0150\u0151\u0170\u0171\u00D8\u00F8\u00E6\u00C6\u00F0\u00D0\u00DE\u00FE\u00DF\u0142\u0219\u021B\u0218\u021A\u0104\u0105\u0106\u0107\u0118\u0119\u0141\u0143\u0144\u00D3\u015A\u015B\u0179\u017A\u017B\u017C\u0103\u0102\u1E9E\u0152\u0153\u015E\u015F\u0162\u0163";
		static String[] ASCII = { "'", "A", "a", "E", "e", "I", "i", "O", "o", "U", "u", "A", "a", "E", "e", "I", "i",
				"o", "U", "u", "Y", "y", "A", "a", "E", "e", "I", "i", "O", "o", "U", "u", "Y", "y", "A", "a", "O", "o",
				"N", "n", "A", "a", "E", "e", "I", "i", "O", "o", "U", "u", "Y", "y", "A", "a", "C", "c", "O", "o", "U",
				"u", "O", "o", "ae", "AE", "eth", "Eth", "th", "Th", "ss", "l", "s", "t", "S", "T" ,"A","a","C","c","E","e","L","N","n","O","S","s","Z","z","Z","z","a","A","SS","OE","oe", "S", "s", "T", "t" };
	
	public static String convertNonAsciiToAscii(String inputPayload) {
	   
	    if (inputPayload == null) {
	      return null;
	    }
	    if (NON_ASCII != null && ASCII != null) {
	      StringBuilder sb = new StringBuilder();
	      int len = inputPayload.length();

	      for (int i = 0; i < len; i++) {
	        char c = inputPayload.charAt(i);
	        if (c < 128) { // ASCII check
	          sb.append(c);
	        } else {
	          int pos = NON_ASCII.indexOf(c);
	          if (pos > -1) {
	            sb.append(ASCII[pos]);
	          } else { 
	        	  sb.append(c);
	          }
	        }
	      }
	      return sb.toString();
	    } else {
	      return inputPayload;
	    }
	  }
	
}